<?php include "layout/header.php"; ?>
<?php //include_once "layout/header.php"; ?>
<?php //require "layout/header.php"; ?>

<?php include "layout/menu.php"; ?>

<div class="container">
	<p>&nbsp;</p>
	<h1>Página principal</h1>
	<?php if(isset($_GET['msg']) && isset($_GET['tipo_msg'])) { ?>
		<div class="alert alert-<?php echo $_GET['tipo_msg']; ?> esconde">
			<?php echo $_GET['msg']; ?>
		</div>
	<?php } ?>
	<div class="row">
		<div class="col">
			
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item active" aria-current="page">Principal</li>
			  </ol>
			</nav>

			<!-- <nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="#">Home</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Biblioteca</li>
			  </ol>
			</nav>

			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="#">Home</a></li>
			    <li class="breadcrumb-item"><a href="#">Biblioteca</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Dados</li>
			  </ol>
			</nav> -->
		</div>
	</div>
	<div class="row">
		<div class="col">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top" src="img/estoque.jpg" alt="Imagem de capa do card">
			  <div class="card-body">
			    <h5 class="card-title">Título do card</h5>
			    <p class="card-text">Um exemplo de texto rápido para construir o título do card e fazer preencher o conteúdo do card.</p>
			    <a href="#" class="btn btn-primary">Visitar</a>
			  </div>
			</div>
		</div>

		<div class="col">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top" src="img/estoque.jpg" alt="Imagem de capa do card">
			  <div class="card-body">
			    <h5 class="card-title">Título do card</h5>
			    <p class="card-text">Um exemplo de texto rápido para construir o título do card e fazer preencher o conteúdo do card.</p>
			    <a href="#" class="btn btn-primary">Visitar</a>
			  </div>
			</div>
		</div>
		<div class="col">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top" src="img/estoque.jpg" alt="Imagem de capa do card">
			  <div class="card-body">
			    <h5 class="card-title">Título do card</h5>
			    <p class="card-text">Um exemplo de texto rápido para construir o título do card e fazer preencher o conteúdo do card.</p>
			    <a href="#" class="btn btn-primary">Visitar</a>
			  </div>
			</div>
		</div>

	</div>

</div>

<?php include "layout/footer.php"; ?>