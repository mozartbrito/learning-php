<?php 

$texto = md5("Geovane@daSilva");

echo $texto;
?>