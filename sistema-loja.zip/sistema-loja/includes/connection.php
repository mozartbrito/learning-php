<?php 
//localhost: host ou domínio da conexão
//root: usuário do banco de dados
//senac: senha do banco de dados
//loja: banco de dados a ser conectado

	$conexao = new mysqli("localhost", "root", "senac", "loja");
?>